package bean;

public class TableInfoColumn {
	private Boolean Choose;
	private Integer Length;
	private String Name;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	public Boolean getChoose() {
		return Choose;
	}
	public void setChoose(Boolean choose) {
		Choose = choose;
	}
	public Integer getLength() {
		return Length;
	}
	public void setLength(Integer length) {
		Length = length;
	}
	
}
